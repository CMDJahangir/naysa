<?php
/**
 * Copyright © 2015 Megnor. All rights reserved.
 */

namespace Megnor\ShopByBrand\Model;

class Cron extends \Magento\Framework\Model\AbstractModel
{

    public function methodName()
    {
        return $this;
    }
}
