var config = {
    map: {
        '*': {
            megnormegamenu:       'Megnor_Category/js/megnormenu',
        }
    },
    shim: {
            'megnormegamenu': {
                deps: ['jquery']
            }
      }   
};
